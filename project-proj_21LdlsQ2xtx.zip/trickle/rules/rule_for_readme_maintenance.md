When updating the project

- Always check if the README.md in trickle/notes needs to be updated
- Update README.md when:
  - New features are added
  - Project structure changes
  - New components are created
  - Technologies or dependencies change
  - Important functionality is modified